package Ejemplo_03;

public interface Entrega {
    void entregarPaquete(String destino);
}
