package Ejemplo_03;

public interface Vigilancia {
    void escanearArea();
}
