package Ejemplo_02;

public class Motor {
    public void arrancar() {
        System.out.println("🚗 Motor: velocidad regulada y marcha iniciada.");
    }
}
