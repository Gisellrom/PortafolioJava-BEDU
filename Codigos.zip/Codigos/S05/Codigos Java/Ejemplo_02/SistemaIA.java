package Ejemplo_02;

public class SistemaIA {
    public void tomarDecision() {
        System.out.println("🧠 IA: trayectoria calculada.");
    }
}
