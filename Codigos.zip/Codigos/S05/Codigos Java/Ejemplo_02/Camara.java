package Ejemplo_02;

public class Camara {
    public void detectarObstaculos() {
        System.out.println("📷 Cámara: obstáculos detectados en el camino.");
    }
}
