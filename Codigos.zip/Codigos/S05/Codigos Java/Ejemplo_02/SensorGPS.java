package Ejemplo_02;

public class SensorGPS {
    public void localizar() {
        System.out.println("📍 GPS: posición actual obtenida.");
    }
}
