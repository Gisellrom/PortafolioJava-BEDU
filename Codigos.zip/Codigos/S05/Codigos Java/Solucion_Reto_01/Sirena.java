package Solucion_Reto_01;

public class Sirena {
    public void activarSirena() {
        System.out.println("🔊 Sirena: Activada.");
    }
}
