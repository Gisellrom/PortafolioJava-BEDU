package Ejemplo_04;

public class GatoRobot extends AnimalRobot {
    @Override
    public void hacerSonido() {
        System.out.println("🐱 GatoRobot: Miau Miau Mecánico");
    }
}
