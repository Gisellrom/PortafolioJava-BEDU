package Ejemplo_04;

public class PajaroRobot extends AnimalRobot {
    @Override
    public void hacerSonido() {
        System.out.println("🐦 PajaroRobot: Pío Pío Cibernético");
    }
}
