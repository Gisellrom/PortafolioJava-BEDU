package Ejemplo_04;

public class PerroRobot extends AnimalRobot {
    @Override
    public void hacerSonido() {
        System.out.println("🐶 PerroRobot: Guau Guau Digital");
    }
}
