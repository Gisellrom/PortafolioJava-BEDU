package Ejemplo_04;

public class AnimalRobot {
    public void hacerSonido() {
        System.out.println("🔊 Sonido genérico de robot animal...");
    }
}
