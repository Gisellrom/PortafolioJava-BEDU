package Solucion_Reto_02;

public interface Autenticable {
    boolean autenticar();
}
