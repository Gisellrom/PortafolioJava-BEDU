package Solucion_Reto_01;

public interface GestorDialogo {
    void mostrarDialogo(PaqueteNarrativo paquete);
}
