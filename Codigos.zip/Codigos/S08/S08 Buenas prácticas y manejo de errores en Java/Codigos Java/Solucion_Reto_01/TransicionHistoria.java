package Solucion_Reto_01;

public interface TransicionHistoria {
    void realizarTransicion(String decision);
}
