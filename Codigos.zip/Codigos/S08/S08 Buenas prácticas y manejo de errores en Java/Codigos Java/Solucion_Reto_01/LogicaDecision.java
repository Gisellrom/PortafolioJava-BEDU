package Solucion_Reto_01;

public interface LogicaDecision {
    String tomarDecision();
}
