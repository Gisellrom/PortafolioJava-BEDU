package Ejemplo_02;

interface EstrategiaCostoEnvio {
    double calcularCosto(Paquete paquete);
}
