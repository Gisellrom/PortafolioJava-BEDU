package Ejemplo_02;

interface Imprimible {
    void imprimirEtiqueta(Paquete paquete);
}
