package Ejemplo_03;

public class Principal {
    public static void main(String[] args) {
        // Crear un objeto de tipo Producto utilizando el constructor
        Producto producto1 = new Producto("Laptop", 12499.99);

        // Llamar al método para mostrar la información del producto
        producto1.mostrarInformacion();
    }
}