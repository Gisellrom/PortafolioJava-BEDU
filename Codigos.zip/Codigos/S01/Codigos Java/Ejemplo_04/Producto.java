package Ejemplo_04;

// Un record es una forma concisa de definir una clase inmutable en Java.
public record Producto(String nombre, double precio) { }
