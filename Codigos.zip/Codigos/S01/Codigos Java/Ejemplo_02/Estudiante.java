package Ejemplo_02;

public class Estudiante {
    // Caracteristicas del estudiante
    String nombre;
    int edad;

    // Método que muestra un saludo con los datos del estudiante
    public void saludar() {
        System.out.println("Hola, mi nombre es " + nombre + " y tengo " + edad + " años.");
    }
}
