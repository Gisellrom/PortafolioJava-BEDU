package Solucion_Reto_02;

// ✅ Record que representa una declaración de impuestos
public record DeclaracionImpuestos(String rfcContribuyente, double montoDeclarado) {
}
