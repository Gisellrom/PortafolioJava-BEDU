package Ejemplo_03;

// ✅ Record inmutable con nombre y edad
public record Empleado(String nombre, Integer edad) { }
