package Solucion_Reto_01;

public class Pasajero {
    String nombre;       // Visibilidad por defecto
    String pasaporte;

    public Pasajero(String nombre, String pasaporte) {
        this.nombre = nombre;
        this.pasaporte = pasaporte;
    }
}