package Ejemplo_02;

public class Persona {
    String nombre;

    public Persona(String nombre) {
        this.nombre = nombre;
    }
}