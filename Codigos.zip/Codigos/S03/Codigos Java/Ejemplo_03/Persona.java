package Ejemplo_03;

public class Persona {

    protected String nacionalidad = "México";
}
