package Ejemplo_03;

public class Empleado extends Persona {
    public void mostrarNacionalidad() {
        System.out.println("🌎 Nacionalidad: " + nacionalidad);
    }
}
